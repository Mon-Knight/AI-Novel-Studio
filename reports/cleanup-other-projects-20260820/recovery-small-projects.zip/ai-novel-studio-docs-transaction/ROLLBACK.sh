#!/usr/bin/env bash
set -euo pipefail
root="${1:?usage: ROLLBACK.sh <repository-copy>}"
patch="F:/ai-novel-studio-docs-transaction/DIFF_FILE"
files=(
  "CHANGELOG.md"
  "docs/agent-runtime.md"
  "docs/ai-agent-roadmap.md"
  "docs/data-model.md"
  "docs/product-design.md"
  "docs/project-architecture.md"
  "docs/ui-reference.md"
  "docs/version-roadmap.md"
  "docs/architecture/conversational-creative-workbench.md"
)
git -C "$root" apply --reverse --check --whitespace=nowarn "$patch"
git -C "$root" apply --reverse --whitespace=nowarn "$patch"
git -C "$root" diff --exit-code -- "${files[@]}"
if [[ -e "$root/docs/architecture/conversational-creative-workbench.md" ]]; then
  echo "ROLLBACK_ERROR: planned design file still exists" >&2
  exit 1
fi
echo "ROLLBACK_OK: restored documentation set to baseline"