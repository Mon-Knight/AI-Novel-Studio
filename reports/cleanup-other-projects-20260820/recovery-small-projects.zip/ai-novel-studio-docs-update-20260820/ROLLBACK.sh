#!/usr/bin/env bash
set -euo pipefail

TARGET_LINUX="${1:?usage: ROLLBACK.sh /mnt/<drive>/<verified-worktree-copy>}"
DIFF_LINUX="/mnt/f/ai-novel-studio-docs-update-20260820/conversational-workbench-docs.diff"
TARGET_WIN="$(wslpath -w "$TARGET_LINUX")"
DIFF_WIN="$(wslpath -w "$DIFF_LINUX")"

printf '%s\n' 'ROLLBACK:'
printf 'COMMAND=git -C %s apply --check -R %s\n' "$TARGET_WIN" "$DIFF_WIN"
printf 'INPUT=%s\n' "$TARGET_WIN"
git.exe -C "$TARGET_WIN" apply --check -R "$DIFF_WIN"
printf '%s\n' 'CHECK=OK'
git.exe -C "$TARGET_WIN" apply -R "$DIFF_WIN"
printf '%s\n' 'APPLY=OK'
STATUS="$(git.exe -C "$TARGET_WIN" status --porcelain)"
if [[ -n "$STATUS" ]]; then
  printf '%s\n' 'STATUS=dirty'
  printf '%s\n' "$STATUS"
  exit 1
fi
printf '%s\n' 'RESULT=restored_to_baseline'
printf '%s\n' 'STATUS=clean'
printf '%s\n' 'EXIT_STATUS=0'