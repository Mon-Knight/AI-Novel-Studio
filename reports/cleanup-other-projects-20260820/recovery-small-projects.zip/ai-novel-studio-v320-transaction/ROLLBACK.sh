#!/usr/bin/env bash
set -euo pipefail

repo="${1:?usage: ROLLBACK.sh /absolute/path/to/repository-copy}"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
patch_file="$script_dir/DIFF_FILE.patch"

git -C "$repo" apply -R --check "$patch_file"
git -C "$repo" apply -R "$patch_file"
git -C "$repo" diff --exit-code --no-ext-diff
echo "ROLLBACK_OK repo=$repo"
